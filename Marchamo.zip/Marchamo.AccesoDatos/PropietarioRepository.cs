﻿using Dapper;
using Marchamo.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Marchamo.AccesoDatos
{
    public class PropietarioRepository : BaseRepository
    {
        // Nombres de SP usados - si tu script tiene otros, cámbialos aquí.
        private const string SP_INSERT = "usp_Propietario_Insertar";
        private const string SP_UPDATE = "usp_Propietario_Actualizar";
        private const string SP_DELETE = "usp_Propietario_EliminarLogico";
        private const string SP_LIST = "usp_Propietario_Listar";
        private const string SP_GET = "usp_Propietario_ObtenerPorId";

        public int Insertar(Propietario entity, string usuario)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters();
                p.Add("@Cedula", entity.Cedula, DbType.String);
                p.Add("@Nombre", entity.Nombre, DbType.String);
                p.Add("@Apellido1", entity.Apellido1, DbType.String);
                p.Add("@Apellido2", entity.Apellido2, DbType.String);
                p.Add("@Telefono", entity.Telefono, DbType.String);
                p.Add("@Correo", entity.Correo, DbType.String);
                p.Add("@Direccion", entity.Direccion, DbType.String);
                p.Add("@Usuario", usuario, DbType.String);
                // Asumiendo que el SP devuelve el id como scalar
                var id = Connection.ExecuteScalar<int>(SP_INSERT, p, commandType: CommandType.StoredProcedure);
                return id;
            }
            catch (Exception ex)
            {
                throw new Exception("PropietarioRepository.Insertar: " + ex.Message, ex);
            }
        }

        public void Actualizar(Propietario entity, string usuario)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters(entity);
                p.Add("@IdPropietario", entity.IdPropietario, DbType.Int32);
                p.Add("@Usuario", usuario, DbType.String);
                Connection.Execute(SP_UPDATE, p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                throw new Exception("PropietarioRepository.Actualizar: " + ex.Message, ex);
            }
        }

        public void EliminarLogico(int idPropietario, string usuario)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters();
                p.Add("@IdPropietario", idPropietario, DbType.Int32);
                p.Add("@Usuario", usuario, DbType.String);
                Connection.Execute(SP_DELETE, p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                throw new Exception("PropietarioRepository.EliminarLogico: " + ex.Message, ex);
            }
        }

        public IEnumerable<Propietario> Listar()
        {
            try
            {
                OpenConnection();
                return Connection.Query<Propietario>(SP_LIST, commandType: CommandType.StoredProcedure).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception("PropietarioRepository.Listar: " + ex.Message, ex);
            }
        }

        public Propietario ObtenerPorId(int id)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters();
                p.Add("@IdPropietario", id, DbType.Int32);
                return Connection.QueryFirstOrDefault<Propietario>(SP_GET, p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                throw new Exception("PropietarioRepository.ObtenerPorId: " + ex.Message, ex);
            }
        }
    }
}

