﻿using Dapper;
using Marchamo.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Marchamo.AccesoDatos
{
    public class AuditoriaRepository : BaseRepository
    {
        private const string SP_INSERT = "sp_Auditoria_Insertar";
        private const string SP_LIST_BY_TABLE = "sp_Auditoria_ListarPorTabla";
        private const string SP_LIST_BY_FECHAS = "sp_Auditoria_ListarPorFechas";

        /// <summary>
        /// Inserta un registro en la tabla de auditoría.
        /// </summary>
        public int Insertar(Auditoria entity)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters();
                p.Add("@NombreTabla", entity.NombreTabla, DbType.String);
                p.Add("@ClaveRegistro", entity.ClaveRegistro, DbType.String);
                p.Add("@TipoOperacion", entity.TipoOperacion, DbType.String);
                p.Add("@ValoresAnteriores", entity.ValoresAnteriores, DbType.String);
                p.Add("@ValoresNuevos", entity.ValoresNuevos, DbType.String);
                p.Add("@UsuarioAccion", entity.UsuarioAccion, DbType.String);
                p.Add("@FechaAccion", entity.FechaAccion, DbType.DateTime);

                // si el SP devuelve el id de auditoría:
                var id = Connection.ExecuteScalar<int>(SP_INSERT, p, commandType: CommandType.StoredProcedure);
                return id;
            }
            catch (Exception ex)
            {
                throw new Exception("AuditoriaRepository.Insertar: " + ex.Message, ex);
            }
        }

        public IEnumerable<Auditoria> ListarPorTabla(string nombreTabla)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters();
                p.Add("@NombreTabla", nombreTabla, DbType.String);
                return Connection.Query<Auditoria>(SP_LIST_BY_TABLE, p, commandType: CommandType.StoredProcedure).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception("AuditoriaRepository.ListarPorTabla: " + ex.Message, ex);
            }
        }

        public IEnumerable<Auditoria> ListarPorFechas(DateTime desde, DateTime hasta)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters();
                p.Add("@FechaDesde", desde, DbType.DateTime);
                p.Add("@FechaHasta", hasta, DbType.DateTime);
                return Connection.Query<Auditoria>(SP_LIST_BY_FECHAS, p, commandType: CommandType.StoredProcedure).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception("AuditoriaRepository.ListarPorFechas: " + ex.Message, ex);
            }
        }
    }
}
