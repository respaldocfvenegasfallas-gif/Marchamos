﻿using Dapper;
using Marchamo.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Marchamo.AccesoDatos
{
    public class VehiculoRepository : BaseRepository
    {
        private const string SP_INSERT = "usp_Vehiculo_Insertar";
        private const string SP_UPDATE = "usp_Vehiculo_Actualizar";
        private const string SP_DELETE = "usp_Vehiculo_EliminarLogico";
        private const string SP_LIST = "usp_Vehiculo_Listar";
        private const string SP_GET = "usp_Vehiculo_ObtenerPorId";
        private const string SP_GET_BY_PLACA = "usp_Vehiculo_ObtenerPorPlaca";

        public int Insertar(Vehiculo entity, string usuario)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters();
                p.Add("@Placa", entity.Placa, DbType.String);
                p.Add("@IdPropietario", entity.IdPropietario, DbType.Int32);
                p.Add("@IdTipoVehiculo", entity.IdTipoVehiculo, DbType.Int32);
                p.Add("@Marca", entity.Marca, DbType.String);
                p.Add("@Modelo", entity.Modelo, DbType.String);
                p.Add("@Annio", entity.Annio, DbType.Int32);
                p.Add("@Cilindraje", entity.Cilindraje, DbType.Int32);
                p.Add("@ValorFiscal", entity.ValorFiscal, DbType.Decimal);
                p.Add("@Usuario", usuario, DbType.String);

                var id = Connection.ExecuteScalar<int>(SP_INSERT, p, commandType: CommandType.StoredProcedure);
                return id;
            }
            catch (Exception ex)
            {
                throw new Exception("VehiculoRepository.Insertar: " + ex.Message, ex);
            }
        }

        public void Actualizar(Vehiculo entity, string usuario)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters(entity);
                p.Add("@IdVehiculo", entity.IdVehiculo, DbType.Int32);
                p.Add("@Usuario", usuario, DbType.String);
                Connection.Execute(SP_UPDATE, p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                throw new Exception("VehiculoRepository.Actualizar: " + ex.Message, ex);
            }
        }

        public void EliminarLogico(int idVehiculo, string usuario)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters();
                p.Add("@IdVehiculo", idVehiculo, DbType.Int32);
                p.Add("@Usuario", usuario, DbType.String);
                Connection.Execute(SP_DELETE, p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                throw new Exception("VehiculoRepository.EliminarLogico: " + ex.Message, ex);
            }
        }

        public IEnumerable<Vehiculo> Listar()
        {
            try
            {
                OpenConnection();
                return Connection.Query<Vehiculo>(SP_LIST, commandType: CommandType.StoredProcedure).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception("VehiculoRepository.Listar: " + ex.Message, ex);
            }
        }

        public Vehiculo ObtenerPorId(int id)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters();
                p.Add("@IdVehiculo", id, DbType.Int32);
                return Connection.QueryFirstOrDefault<Vehiculo>(SP_GET, p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                throw new Exception("VehiculoRepository.ObtenerPorId: " + ex.Message, ex);
            }
        }

        public Vehiculo ObtenerPorPlaca(string placa)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters();
                p.Add("@Placa", placa, DbType.String);
                return Connection.QueryFirstOrDefault<Vehiculo>(SP_GET_BY_PLACA, p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                throw new Exception("VehiculoRepository.ObtenerPorPlaca: " + ex.Message, ex);
            }
        }
    }
}
