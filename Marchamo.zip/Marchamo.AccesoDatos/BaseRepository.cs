﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace Marchamo.AccesoDatos
{
    public abstract class BaseRepository : IDisposable
    {
        private readonly string _cs;
        protected SqlConnection Connection { get; private set; }
        protected SqlTransaction Transaction { get; private set; }

        protected BaseRepository()
        {
            _cs = ConfigurationManager.ConnectionStrings["CN_Marchamo"].ConnectionString;
            Connection = new SqlConnection(_cs);
        }

        protected void OpenConnection()
        {
            if (Connection.State != ConnectionState.Open)
                Connection.Open();
        }

        protected void BeginTransaction()
        {
            OpenConnection();
            Transaction = Connection.BeginTransaction();
        }

        protected void Commit()
        {
            Transaction?.Commit();
            Transaction = null;
        }

        protected void Rollback()
        {
            try { Transaction?.Rollback(); } catch { /* nothing */ }
            Transaction = null;
        }

        public void Dispose()
        {
            try
            {
                Transaction?.Dispose();
            }
            catch { }
            try
            {
                if (Connection != null && Connection.State != ConnectionState.Closed)
                    Connection.Close();
                Connection?.Dispose();
            }
            catch { }
        }
    }
}
