﻿using Dapper;
using Marchamo.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Marchamo.AccesoDatos
{
    public class SeguroRepository : BaseRepository
    {
        private const string SP_LIST = "usp_SeguroAdicional_Listar";
        private const string SP_GET = "usp_SeguroAdicional_ObtenerPorId";
        private const string SP_INSERT = "usp_SeguroAdicional_Insertar";
        private const string SP_UPDATE = "usp_SeguroAdicional_Actualizar";
        private const string SP_DELETE = "usp_SeguroAdicional_EliminarLogico";

        public IEnumerable<SeguroAdicional> Listar()
        {
            try
            {
                OpenConnection();
                return Connection.Query<SeguroAdicional>(SP_LIST, commandType: CommandType.StoredProcedure).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception("SeguroRepository.Listar: " + ex.Message, ex);
            }
        }

        public SeguroAdicional ObtenerPorId(int id)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters();
                p.Add("@IdSeguroAdicional", id, DbType.Int32);
                return Connection.QueryFirstOrDefault<SeguroAdicional>(SP_GET, p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                throw new Exception("SeguroRepository.ObtenerPorId: " + ex.Message, ex);
            }
        }

        public int Insertar(SeguroAdicional entity, string usuario)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters(entity);
                p.Add("@Usuario", usuario, DbType.String);
                var id = Connection.ExecuteScalar<int>(SP_INSERT, p, commandType: CommandType.StoredProcedure);
                return id;
            }
            catch (Exception ex)
            {
                throw new Exception("SeguroRepository.Insertar: " + ex.Message, ex);
            }
        }

        public void Actualizar(SeguroAdicional entity, string usuario)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters(entity);
                p.Add("@IdSeguroAdicional", entity.IdSeguroAdicional, DbType.Int32);
                p.Add("@Usuario", usuario, DbType.String);
                Connection.Execute(SP_UPDATE, p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                throw new Exception("SeguroRepository.Actualizar: " + ex.Message, ex);
            }
        }

        public void EliminarLogico(int id, string usuario)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters();
                p.Add("@IdSeguroAdicional", id, DbType.Int32);
                p.Add("@Usuario", usuario, DbType.String);
                Connection.Execute(SP_DELETE, p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                throw new Exception("SeguroRepository.EliminarLogico: " + ex.Message, ex);
            }
        }
    }
}
