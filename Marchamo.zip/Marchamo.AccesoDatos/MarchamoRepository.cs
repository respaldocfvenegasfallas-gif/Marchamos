﻿using Dapper;
using Marchamo.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Marchamo.AccesoDatos
{
    public class MarchamoPendienteDto
    {
        public int IdMarchamo { get; set; }
        public string Placa { get; set; }
        public int Annio { get; set; }
        public decimal SaldoBase { get; set; }
        public DateTime FechaVencimiento { get; set; }
        public int DiasMora { get; set; }
        public decimal MontoSOA { get; set; }
        public decimal MoraSOA { get; set; }
        public decimal MultaFija { get; set; }
        public decimal TotalConMora { get; set; }
    }

    public class MarchamoRepository : BaseRepository
    {
        private const string SP_CONSULTA_PENDIENTES = "usp_Marchamo_ConsultarPendientesPorPlacaConMora";
        private const string SP_CONSULTA_POR_PLACA = "usp_Marchamo_ConsultarPorPlaca";
        private const string SP_GENERAR = "usp_Marchamo_Generar"; // si tienes SP para generar marchamo

        public IEnumerable<MarchamoPendienteDto> ConsultarPendientesPorPlaca(string placa)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters();
                p.Add("@Placa", placa, DbType.String);
                using (var multi = Connection.QueryMultiple(SP_CONSULTA_PENDIENTES, p, commandType: CommandType.StoredProcedure))
                {
                    var detalle = multi.Read<MarchamoPendienteDto>().ToList();

                    // Si el SP devuelve resumen en 2do resultset lo podemos leer:
                    // var resumen = multi.ReadFirstOrDefault();

                    return detalle;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("MarchamoRepository.ConsultarPendientesPorPlaca: " + ex.Message, ex);
            }
        }

        public Marchamo ObtenerPorPlacaAnno(string placa, int anno)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters();
                p.Add("@Placa", placa, DbType.String);
                p.Add("@Anno", anno, DbType.Int32);
                return Connection.QueryFirstOrDefault<Marchamo>(SP_CONSULTA_POR_PLACA, p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                throw new Exception("MarchamoRepository.ObtenerPorPlacaAnno: " + ex.Message, ex);
            }
        }

        // Ejemplo de método para generar marchamo (orquestado por la capa de negocio)
        // Asume que el SP genera registros en Marchamo + DetalleMarchamo y devuelve el id generado.

        public int GenerarMarchamo(int idVehiculo, int anno, DateTime fechaVencimiento, string usuario)
        {
            try
            {
                OpenConnection();
                BeginTransaction();
                var p = new DynamicParameters();
                p.Add("@IdVehiculo", idVehiculo, DbType.Int32);
                p.Add("@Anno", anno, DbType.Int32);
                p.Add("@Fecha_Venc", fechaVencimiento, DbType.Date); // nombre exacto del SP: @fecha_venc
                p.Add("@Usuario", usuario, DbType.String);
                var id = Connection.ExecuteScalar<int>("usp_Marchamo_Generar", p, transaction: Transaction, commandType: CommandType.StoredProcedure);
                Commit();
                return id;
            }
            catch (Exception ex) { Rollback(); throw new Exception("MarchamoRepository.GenerarMarchamo: " + ex.Message, ex); }
        }

    }
}
