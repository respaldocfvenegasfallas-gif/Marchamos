﻿using Dapper;
using Marchamo.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Marchamo.AccesoDatos
{
    public class PagoRepository : BaseRepository
    {
        private const string SP_INSERT = "usp_Pago_Registrar";
        private const string SP_LIST_BY_MARCHAMO = "usp_Pago_ListarPorMarchamo";

        public int RegistrarPago(Pago pEntity, string usuario)
        {
            try
            {
                OpenConnection();
                BeginTransaction();

                var p = new DynamicParameters();
                p.Add("@IdMarchamo", pEntity.IdMarchamo, DbType.Int32);
                p.Add("@FechaPago", pEntity.FechaPago, DbType.DateTime);
                p.Add("@IdMedioPago", pEntity.IdMedioPago, DbType.Int32);
                p.Add("@Monto", pEntity.Monto, DbType.Decimal);
                p.Add("@Autorizacion", pEntity.Autorizacion, DbType.String);
                p.Add("@Referencia", pEntity.Referencia, DbType.String);
                p.Add("@Usuario", usuario, DbType.String);

                var id = Connection.ExecuteScalar<int>(SP_INSERT, p, transaction: Transaction, commandType: CommandType.StoredProcedure);

                // Opcional: actualizar TotalPagado en Marchamo (si el SP no lo hace)
                // Connection.Execute("usp_Marchamo_ActualizarTotalPagado", new { IdMarchamo = pEntity.IdMarchamo }, transaction: Transaction, commandType: CommandType.StoredProcedure);

                Commit();
                return id;
            }
            catch (Exception ex)
            {
                Rollback();
                throw new Exception("PagoRepository.RegistrarPago: " + ex.Message, ex);
            }
        }

        public IEnumerable<Pago> ListarPorMarchamo(int idMarchamo)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters();
                p.Add("@IdMarchamo", idMarchamo, DbType.Int32);
                return Connection.Query<Pago>(SP_LIST_BY_MARCHAMO, p, commandType: CommandType.StoredProcedure).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception("PagoRepository.ListarPorMarchamo: " + ex.Message, ex);
            }
        }
    }
}
