﻿using Dapper;
using Marchamo.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Marchamo.AccesoDatos
{
    public class TipoConceptoRepository : BaseRepository
    {
        private const string SP_LIST = "usp_TipoConcepto_Listar";
        private const string SP_GET = "usp_TipoConcepto_ObtenerPorId";

        public IEnumerable<TipoConceptoMarchamo> Listar()
        {
            try
            {
                OpenConnection();
                return Connection.Query<TipoConceptoMarchamo>(SP_LIST, commandType: CommandType.StoredProcedure).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception("TipoConceptoRepository.Listar: " + ex.Message, ex);
            }
        }

        public TipoConceptoMarchamo ObtenerPorId(int id)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters();
                p.Add("@IdTipoConcepto", id, DbType.Int32);
                return Connection.QueryFirstOrDefault<TipoConceptoMarchamo>(SP_GET, p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                throw new Exception("TipoConceptoRepository.ObtenerPorId: " + ex.Message, ex);
            }
        }
    }

    public class ReglaConceptoRepository : BaseRepository
    {
        private const string SP_LIST_BY_ANNO = "usp_ReglaConcepto_ListarPorAnno";
        private const string SP_INSERT = "usp_ReglaConcepto_Insertar";
        private const string SP_DELETE = "usp_ReglaConcepto_Eliminar";

        public IEnumerable<ReglaConceptoMarchamo> ListarPorAnno(int anno)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters();
                p.Add("@Anno", anno, DbType.Int32);
                return Connection.Query<ReglaConceptoMarchamo>(SP_LIST_BY_ANNO, p, commandType: CommandType.StoredProcedure).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception("ReglaConceptoRepository.ListarPorAnno: " + ex.Message, ex);
            }
        }

        public int Insertar(ReglaConceptoMarchamo regla, string usuario)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters(regla);
                p.Add("@Usuario", usuario, DbType.String);
                var id = Connection.ExecuteScalar<int>(SP_INSERT, p, commandType: CommandType.StoredProcedure);
                return id;
            }
            catch (Exception ex)
            {
                throw new Exception("ReglaConceptoRepository.Insertar: " + ex.Message, ex);
            }
        }

        public void Eliminar(int id, string usuario)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters();
                p.Add("@IdRegla", id, DbType.Int32);
                p.Add("@Usuario", usuario, DbType.String);
                Connection.Execute(SP_DELETE, p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                throw new Exception("ReglaConceptoRepository.Eliminar: " + ex.Message, ex);
            }
        }
    }
}
