﻿using Dapper;
using Marchamo.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Marchamo.AccesoDatos
{
    public class SegRolRepository : BaseRepository
    {
        // Ajusta estos nombres si en tu script usan otros (ej. sp_SegRol_Insertar)
        private const string SP_INSERT = "sp_SegRol_Insertar";
        private const string SP_UPDATE = "sp_SegRol_Actualizar";
        private const string SP_DELETE = "sp_SegRol_EliminarLogico";
        private const string SP_LIST = "sp_SegRol_Listar";
        private const string SP_GET = "sp_SegRol_ObtenerPorId";

        public int Insertar(SegRol entity, string usuario)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters();
                p.Add("@Nombre", entity.Nombre, DbType.String);
                p.Add("@Descripcion", entity.Descripcion, DbType.String);
                p.Add("@EsAdministrador", entity.EsAdministrador, DbType.Boolean);
                p.Add("@Usuario", usuario, DbType.String);

                // Asumimos que el SP retorna el id (OUTPUT o SELECT SCOPE_IDENTITY)
                var id = Connection.ExecuteScalar<int>(SP_INSERT, p, commandType: CommandType.StoredProcedure);
                return id;
            }
            catch (Exception ex)
            {
                throw new Exception("SegRolRepository.Insertar: " + ex.Message, ex);
            }
        }

        public void Actualizar(SegRol entity, string usuario)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters();
                p.Add("@IdRol", entity.IdRol, DbType.Int32);
                p.Add("@Nombre", entity.Nombre, DbType.String);
                p.Add("@Descripcion", entity.Descripcion, DbType.String);
                p.Add("@EsAdministrador", entity.EsAdministrador, DbType.Boolean);
                p.Add("@Usuario", usuario, DbType.String);

                Connection.Execute(SP_UPDATE, p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                throw new Exception("SegRolRepository.Actualizar: " + ex.Message, ex);
            }
        }

        public void EliminarLogico(int idRol, string usuario)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters();
                p.Add("@IdRol", idRol, DbType.Int32);
                p.Add("@Usuario", usuario, DbType.String);
                Connection.Execute(SP_DELETE, p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                throw new Exception("SegRolRepository.EliminarLogico: " + ex.Message, ex);
            }
        }

        public IEnumerable<SegRol> Listar()
        {
            try
            {
                OpenConnection();
                return Connection.Query<SegRol>(SP_LIST, commandType: CommandType.StoredProcedure).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception("SegRolRepository.Listar: " + ex.Message, ex);
            }
        }

        public SegRol ObtenerPorId(int idRol)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters();
                p.Add("@IdRol", idRol, DbType.Int32);
                return Connection.QueryFirstOrDefault<SegRol>(SP_GET, p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                throw new Exception("SegRolRepository.ObtenerPorId: " + ex.Message, ex);
            }
        }
    }
}
