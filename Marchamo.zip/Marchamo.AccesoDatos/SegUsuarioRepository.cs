﻿using Dapper;
using Marchamo.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Marchamo.AccesoDatos
{
    public class SegUsuarioRepository : BaseRepository
    {
        // Ajusta nombres de SP si en tu script son distintos
        private const string SP_INSERT = "sp_SegUsuario_Insertar";
        private const string SP_UPDATE = "sp_SegUsuario_Actualizar";
        private const string SP_DELETE = "sp_SegUsuario_EliminarLogico";
        private const string SP_LIST = "sp_SegUsuario_Listar";
        private const string SP_GET = "sp_SegUsuario_ObtenerPorId";
        private const string SP_GET_BY_USERNAME = "sp_SegUsuario_ObtenerPorNombreUsuario";
        private const string SP_UPDATE_PASSWORD = "sp_SegUsuario_ActualizarPassword";
        private const string SP_INCREMENT_INTENTOS = "sp_SegUsuario_IncrementarIntentos";
        private const string SP_RESET_INTENTOS = "sp_SegUsuario_ResetearIntentos";
        // opcional: bitacora de accesos
        private const string SP_REGISTRAR_ACCESO = "sp_SegBitacoraAcceso_Insertar";

        public int Insertar(SegUsuario entity, string usuario)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters();
                p.Add("@NombreUsuario", entity.NombreUsuario, DbType.String);
                p.Add("@ClaveHash", entity.ClaveHash, DbType.Binary);
                p.Add("@ClaveSalt", entity.ClaveSalt, DbType.Binary);
                p.Add("@NombreCompleto", entity.NombreCompleto, DbType.String);
                p.Add("@Correo", entity.Correo, DbType.String);
                p.Add("@EsActivo", entity.EsActivo, DbType.Boolean);
                p.Add("@Usuario", usuario, DbType.String);

                var id = Connection.ExecuteScalar<int>(SP_INSERT, p, commandType: CommandType.StoredProcedure);
                return id;
            }
            catch (Exception ex)
            {
                throw new Exception("SegUsuarioRepository.Insertar: " + ex.Message, ex);
            }
        }

        public void Actualizar(SegUsuario entity, string usuario)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters();
                p.Add("@IdUsuario", entity.IdUsuario, DbType.Int32);
                p.Add("@NombreCompleto", entity.NombreCompleto, DbType.String);
                p.Add("@Correo", entity.Correo, DbType.String);
                p.Add("@EsActivo", entity.EsActivo, DbType.Boolean);
                p.Add("@Usuario", usuario, DbType.String);

                Connection.Execute(SP_UPDATE, p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                throw new Exception("SegUsuarioRepository.Actualizar: " + ex.Message, ex);
            }
        }

        public void EliminarLogico(int idUsuario, string usuario)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters();
                p.Add("@IdUsuario", idUsuario, DbType.Int32);
                p.Add("@Usuario", usuario, DbType.String);
                Connection.Execute(SP_DELETE, p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                throw new Exception("SegUsuarioRepository.EliminarLogico: " + ex.Message, ex);
            }
        }

        public IEnumerable<SegUsuario> Listar()
        {
            try
            {
                OpenConnection();
                return Connection.Query<SegUsuario>(SP_LIST, commandType: CommandType.StoredProcedure).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception("SegUsuarioRepository.Listar: " + ex.Message, ex);
            }
        }

        public SegUsuario ObtenerPorId(int idUsuario)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters();
                p.Add("@IdUsuario", idUsuario, DbType.Int32);
                return Connection.QueryFirstOrDefault<SegUsuario>(SP_GET, p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                throw new Exception("SegUsuarioRepository.ObtenerPorId: " + ex.Message, ex);
            }
        }

        public SegUsuario ObtenerPorNombreUsuario(string nombreUsuario)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters();
                p.Add("@NombreUsuario", nombreUsuario, DbType.String);
                return Connection.QueryFirstOrDefault<SegUsuario>(SP_GET_BY_USERNAME, p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                throw new Exception("SegUsuarioRepository.ObtenerPorNombreUsuario: " + ex.Message, ex);
            }
        }

        /// <summary>
        /// Actualiza hash y salt de la contraseña (por ejemplo al resetear password)
        /// </summary>
        public void ActualizarPassword(int idUsuario, byte[] claveHash, byte[] claveSalt, string usuario)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters();
                p.Add("@IdUsuario", idUsuario, DbType.Int32);
                p.Add("@ClaveHash", claveHash, DbType.Binary);
                p.Add("@ClaveSalt", claveSalt, DbType.Binary);
                p.Add("@Usuario", usuario, DbType.String);
                Connection.Execute(SP_UPDATE_PASSWORD, p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                throw new Exception("SegUsuarioRepository.ActualizarPassword: " + ex.Message, ex);
            }
        }

        public void IncrementarIntentos(int idUsuario)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters();
                p.Add("@IdUsuario", idUsuario, DbType.Int32);
                Connection.Execute(SP_INCREMENT_INTENTOS, p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                throw new Exception("SegUsuarioRepository.IncrementarIntentos: " + ex.Message, ex);
            }
        }

        public void ResetearIntentos(int idUsuario)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters();
                p.Add("@IdUsuario", idUsuario, DbType.Int32);
                Connection.Execute(SP_RESET_INTENTOS, p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                throw new Exception("SegUsuarioRepository.ResetearIntentos: " + ex.Message, ex);
            }
        }

        /// <summary>
        /// Registra intento de acceso en la bitácora. Usa SP para insertar en SegBitacoraAcceso
        /// </summary>
        public void RegistrarAccesoEnBitacora(int? idUsuario, bool exitoso, string direccionIp, string detalle)
        {
            try
            {
                OpenConnection();
                var p = new DynamicParameters();
                p.Add("@IdUsuario", idUsuario, DbType.Int32);
                p.Add("@Exitoso", exitoso, DbType.Boolean);
                p.Add("@DireccionIP", direccionIp, DbType.String);
                p.Add("@Detalle", detalle, DbType.String);

                Connection.Execute(SP_REGISTRAR_ACCESO, p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                throw new Exception("SegUsuarioRepository.RegistrarAccesoEnBitacora: " + ex.Message, ex);
            }
        }
    }
}
