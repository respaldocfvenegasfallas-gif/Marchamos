﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Marchamo.Entidades
{
    public class Propietario
    {
        public int IdPropietario { get; set; }           // id_propietario
        public string Cedula { get; set; }               // cedula
        public string Nombre { get; set; }               // nombre
        public string Apellido1 { get; set; }            // apellido1
        public string Apellido2 { get; set; }            // apellido2 (nullable)
        public string Telefono { get; set; }             // telefono
        public string Correo { get; set; }               // correo
        public string Direccion { get; set; }            // direccion
        public bool EsActivo { get; set; }               // es_activo
        public string UsuarioCrea { get; set; }          // usuario_crea
        public System.DateTime FechaCrea { get; set; }   // fecha_crea
        public string UsuarioModifica { get; set; }      // usuario_modifica
        public System.DateTime? FechaModifica { get; set; } // fecha_modifica
    }
}
