﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Marchamo.Entidades
{
    public class Pago
    {
        public int IdPago { get; set; }                  // id_pago
        public int IdMarchamo { get; set; }              // id_marchamo
        public System.DateTime FechaPago { get; set; }   // fecha_pago
        public int IdMedioPago { get; set; }             // id_medio_pago
        public decimal Monto { get; set; }               // monto
        public string Autorizacion { get; set; }         // autorizacion
        public string Referencia { get; set; }           // referencia
        public bool EsActivo { get; set; }               // es_activo
        public string UsuarioCrea { get; set; }          // usuario_crea
        public System.DateTime FechaCrea { get; set; }   // fecha_crea
        public string UsuarioModifica { get; set; }      // usuario_modifica
        public System.DateTime? FechaModifica { get; set; } // fecha_modifica

    }
}
