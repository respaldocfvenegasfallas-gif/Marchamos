﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Marchamo.Entidades
{
    public class Marchamo
    {
        public int IdMarchamo { get; set; }              // id_marchamo
        public int IdVehiculo { get; set; }              // id_vehiculo
        public int Annio { get; set; }                   // annio
        public System.DateTime FechaEmision { get; set; } // fecha_emision
        public System.DateTime FechaVencimiento { get; set; } // fecha_vencimiento
        public int IdEstadoMarchamo { get; set; }        // id_estado_marchamo
        public decimal TotalPagar { get; set; }          // total_pagar
        public decimal TotalPagado { get; set; }         // total_pagado
        public string CodigoMarchamo { get; set; }       // codigo_marchamo
        public bool EsActivo { get; set; }               // es_activo
        public string UsuarioCrea { get; set; }          // usuario_crea
        public System.DateTime FechaCrea { get; set; }   // fecha_crea
        public string UsuarioModifica { get; set; }      // usuario_modifica
        public System.DateTime? FechaModifica { get; set; } // fecha_modifica

    }
}
