﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Marchamo.Entidades
{
    public class ReglaConceptoMarchamo
    {
        public int IdRegla { get; set; }                 // id_regla
        public int IdTipoConcepto { get; set; }          // id_tipo_concepto
        public int? IdTipoVehiculo { get; set; }         // id_tipo_vehiculo (nullable)
        public int AnnioDesde { get; set; }              // annio_desde
        public int AnnioHasta { get; set; }              // annio_hasta
        public string TipoCalculo { get; set; }          // tipo_calculo
        public decimal? Porcentaje { get; set; }         // porcentaje
        public decimal? MontoFijo { get; set; }          // monto_fijo
        public decimal? MontoMinimo { get; set; }        // monto_minimo
        public decimal? MontoMaximo { get; set; }        // monto_maximo
        public bool EsActivo { get; set; }               // es_activo
        public string UsuarioCrea { get; set; }          // usuario_crea
        public System.DateTime FechaCrea { get; set; }   // fecha_crea
        public string UsuarioModifica { get; set; }      // usuario_modifica
        public System.DateTime? FechaModifica { get; set; } // fecha_modifica

    }
}
