﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Marchamo.Entidades
{
    public class SegBitacoraAcceso
    {
        public int IdAcceso { get; set; }                // id_acceso
        public int IdUsuario { get; set; }               // id_usuario
        public System.DateTime FechaAcceso { get; set; } // fecha_acceso
        public bool Exitoso { get; set; }                // exitoso
        public string DireccionIP { get; set; }          // direccion_IP
        public string Detalle { get; set; }              // detalle

    }
}
