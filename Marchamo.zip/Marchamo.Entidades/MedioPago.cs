﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Marchamo.Entidades
{
    public class MedioPago
    {
        public int IdMedioPago { get; set; }             // id_medio_pago
        public string Nombre { get; set; }               // nombre
        public bool EsActivo { get; set; }               // es_activo
        public string UsuarioCrea { get; set; }
        public DateTime FechaCrea { get; set; }
        public string UsuarioModifica { get; set; }
        public DateTime? FechaModifica { get; set; }

    }
}
