﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Marchamo.Entidades
{
    public class SegUsuario
    {
        public int IdUsuario { get; set; }                // id_usuario
        public string NombreUsuario { get; set; }        // nombre_usuario
        public byte[] ClaveHash { get; set; }            // clave_hash
        public byte[] ClaveSalt { get; set; }            // clave_salt
        public string NombreCompleto { get; set; }       // nombre_completo
        public string Correo { get; set; }               // correo
        public int IntentosFallidos { get; set; }        // intentos_fallidos
        public System.DateTime? UltimoLogin { get; set; } // ultimo_login
        public bool EsActivo { get; set; }               // es_activo
        public string UsuarioCrea { get; set; }          // usuario_crea
        public System.DateTime FechaCrea { get; set; }   // fecha_crea
        public string UsuarioModifica { get; set; }      // usuario_modifica
        public System.DateTime? FechaModifica { get; set; } // fecha_modifica

    }
}
