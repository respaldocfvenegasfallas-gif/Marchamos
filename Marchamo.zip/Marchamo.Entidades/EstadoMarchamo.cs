﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Marchamo.Entidades
{
    public class EstadoMarchamo
    {
        public int IdEstadoMarchamo { get; set; }        // id_estado_marchamo
        public string Nombre { get; set; }               // nombre

    }
}
