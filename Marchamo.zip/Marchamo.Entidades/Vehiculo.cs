﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Marchamo.Entidades
{
    public class Vehiculo
    {
        public int IdVehiculo { get; set; }              // id_vehiculo
        public string Placa { get; set; }                // placa
        public int IdPropietario { get; set; }           // id_propietario
        public int IdTipoVehiculo { get; set; }          // id_tipo_vehiculo
        public string Marca { get; set; }                // marca
        public string Modelo { get; set; }               // modelo
        public int Annio { get; set; }                   // annio
        public int? Cilindraje { get; set; }             // cilindraje (nullable)
        public decimal ValorFiscal { get; set; }         // valor_fiscal
        public System.DateTime FechaRegistro { get; set; } // fecha_registro (DATE mapped to DateTime)
        public bool EsActivo { get; set; }               // es_activo
        public string UsuarioCrea { get; set; }          // usuario_crea
        public System.DateTime FechaCrea { get; set; }   // fecha_crea
        public string UsuarioModifica { get; set; }      // usuario_modifica
        public System.DateTime? FechaModifica { get; set; } // fecha_modifica
    }
}
