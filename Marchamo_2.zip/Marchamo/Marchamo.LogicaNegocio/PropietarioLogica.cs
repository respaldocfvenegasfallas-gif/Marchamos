﻿using Marchamo.AccesoDatos;
using Marchamo.Entidades;
using System;
using System.Collections.Generic;

namespace Marchamo.LogicaNegocio
{
    public class PropietarioLogica
    {
        private readonly PropietarioRepository _repositorio;

        public PropietarioLogica()
        {
            _repositorio = new PropietarioRepository();
        }

        public int Insertar(Propietario entidad, string usuario)
        {
            // Regla de Negocio: Validar datos antes de ir a BD
            if (string.IsNullOrEmpty(entidad.Cedula))
                throw new ApplicationException("La cédula es requerida.");

            // El Repositorio lanzará excepción si la cédula ya existe (manejado por SQL)
            return _repositorio.Insertar(entidad, usuario);
        }

        public void Actualizar(Propietario entidad, string usuario)
        {
            var existente = _repositorio.ObtenerPorId(entidad.IdPropietario);
            if (existente == null)
                throw new ApplicationException("El propietario que intenta modificar no existe.");

            _repositorio.Actualizar(entidad, usuario);
        }

        public void Eliminar(int idPropietario, string usuario)
        {
            _repositorio.Eliminar(idPropietario, usuario);
        }

        public IEnumerable<Propietario> Listar(string busqueda = null)
        {
            // Llama al repositorio con paginación por defecto (puedes ampliar esto si la UI lo pide)
            return _repositorio.Listar(busqueda);
        }

        public Propietario ObtenerPorId(int id)
        {
            return _repositorio.ObtenerPorId(id);
        }
    }
}