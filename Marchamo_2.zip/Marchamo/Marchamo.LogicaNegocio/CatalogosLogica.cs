﻿using Marchamo.AccesoDatos;
using Marchamo.Entidades;
using System.Collections.Generic;

namespace Marchamo.LogicaNegocio
{
    public class CatalogosLogica
    {
        private readonly CatalogosRepository _repositorio;

        public CatalogosLogica()
        {
            _repositorio = new CatalogosRepository();
        }

        public IEnumerable<TipoVehiculo> ListarTiposVehiculo()
        {
            return _repositorio.ListarTiposVehiculo();
        }

        public IEnumerable<MedioPago> ListarMediosPago()
        {
            return _repositorio.ListarMediosPago();
        }

        public IEnumerable<SeguroAdicional> ListarSegurosAdicionales()
        {
            return _repositorio.ListarSegurosAdicionales();
        }
    }
}