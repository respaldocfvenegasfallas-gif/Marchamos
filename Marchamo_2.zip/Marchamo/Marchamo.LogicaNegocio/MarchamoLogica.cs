﻿using Marchamo.AccesoDatos;
using Marchamo.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Marchamo.LogicaNegocio
{
    public class MarchamoLogica
    {
        private readonly MarchamoRepository _repositorio;

        public MarchamoLogica()
        {
            _repositorio = new MarchamoRepository();
        }

        public Marchamo.Entidades.Marchamo GenerarMarchamo(int idVehiculo, string usuario)
        {
            // Regla de Negocio: Se cobra el periodo 2026 (Ley 10390)
            int annioPeriodo = 2026;
            DateTime fechaVencimiento = new DateTime(2025, 12, 31); // Vence fin de 2025

            return _repositorio.Generar(idVehiculo, annioPeriodo, fechaVencimiento, usuario);
        }

        public List<dynamic> ConsultarPorPlaca(string placa)
        {
            if (string.IsNullOrWhiteSpace(placa))
                throw new ApplicationException("Debe ingresar un número de placa.");

            // El SP 'usp_Marchamo_ConsultarPorPlaca' ya filtra por año 2026
            var resultado = _repositorio.ConsultarPorPlaca(placa).ToList();

            if (resultado.Count == 0)
                return new List<dynamic>(); // Retorna vacío si no hay cobro generado

            return resultado;
        }

        public List<dynamic> ObtenerDetalle(int idMarchamo)
        {
            return _repositorio.ObtenerDetalle(idMarchamo).ToList();
        }

        public void AgregarSeguroAdicional(int idMarchamo, int idSeguroAdicional, string usuario)
        {
            _repositorio.AgregarSeguroAdicional(idMarchamo, idSeguroAdicional, usuario);
        }
    }
}