﻿using Marchamo.AccesoDatos;
using Marchamo.Entidades;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Marchamo.LogicaNegocio
{
    public class AdminLogica
    {
        // Repositorios existentes
        private readonly PropietarioRepository _repoProp = new PropietarioRepository();
        private readonly VehiculoRepository _repoVeh = new VehiculoRepository();

        // Nuevos repositorios para la gestión administrativa
        private readonly SeguridadRepository _repoSeguridad = new SeguridadRepository();
        private readonly MarchamoRepository _repoMarchamo = new MarchamoRepository();

        // =========================================================================
        // 1. CARGA MASIVA DE FLOTILLA (Desde CSV)
        // =========================================================================
        public List<string> ProcesarCargaMasiva(Stream archivoStream, string usuarioAdmin)
        {
            var errores = new List<string>();
            int lineaActual = 0;

            using (var reader = new StreamReader(archivoStream))
            {
                while (!reader.EndOfStream)
                {
                    lineaActual++;
                    var linea = reader.ReadLine();
                    if (string.IsNullOrWhiteSpace(linea)) continue;

                    var datos = linea.Split(','); // CSV separado por comas

                    // Validación básica de columnas
                    if (datos.Length < 9)
                    {
                        errores.Add($"Línea {lineaActual}: Formato incorrecto. Se esperan 9 columnas.");
                        continue;
                    }

                    try
                    {
                        // A. Mapeo de Datos
                        string cedula = datos[0].Trim();
                        string nombre = datos[1].Trim();
                        string apellido = datos[2].Trim();
                        string placa = datos[3].Trim();
                        int idClase = int.Parse(datos[4].Trim()); // 1=Particular, 2=Moto...
                        string marca = datos[5].Trim();
                        string modelo = datos[6].Trim();
                        int annio = int.Parse(datos[7].Trim());
                        decimal valor = decimal.Parse(datos[8].Trim());

                        // B. Gestión de Propietario (Upsert simulado)
                        int idPropietario = 0;
                        try
                        {
                            var propNuevo = new Propietario
                            {
                                Cedula = cedula,
                                Nombre = nombre,
                                Apellido1 = apellido,
                                Apellido2 = "" // CSV simple no trae segundo apellido
                            };
                            idPropietario = _repoProp.Insertar(propNuevo, usuarioAdmin);
                        }
                        catch
                        {
                            // Si falla el insert, asumimos que ya existe.
                            // En un entorno ideal, usaríamos _repoProp.ObtenerPorCedula(cedula).
                            // Por ahora, para no romper la carga, continuamos si la BD maneja la duplicidad.
                            // (Nota: Si tu SP devuelve error, el vehículo no se insertará, lo cual es correcto).
                            // Para corregirlo al 100%, deberías implementar ObtenerPorCedula en el Repo.

                            // Parche de flujo: Si ya existe, necesitamos su ID para el vehículo.
                            // Como no tenemos el método 'ObtenerIdPorCedula', reportamos advertencia.
                            errores.Add($"Línea {lineaActual}: El propietario {cedula} ya existe. (Se requiere método de búsqueda para asociar)");
                            continue;
                        }

                        // C. Insertar Vehículo
                        var vehiculo = new Vehiculo
                        {
                            Placa = placa,
                            IdPropietario = idPropietario,
                            IdTipoVehiculo = idClase,
                            Marca = marca,
                            Modelo = modelo,
                            Annio = annio,
                            ValorFiscal = valor,
                            PorcentajeExoneracion = 0 // Por defecto 0 en carga masiva simple
                        };

                        _repoVeh.Insertar(vehiculo, usuarioAdmin);
                    }
                    catch (Exception ex)
                    {
                        errores.Add($"Línea {lineaActual} (Placa {datos[3]}): {ex.Message}");
                    }
                }
            }

            return errores;
        }

        // =========================================================================
        // 2. GESTIÓN DE USUARIOS (Dashboard Admin)
        // =========================================================================
        public IEnumerable<dynamic> ListarUsuarios()
        {
            return _repoSeguridad.ListarUsuariosAdmin();
        }

        public void CambiarEstadoUsuario(int idUsuario, bool activo)
        {
            _repoSeguridad.CambiarEstadoUsuario(idUsuario, activo);
        }

        // =========================================================================
        // 3. REPORTES
        // =========================================================================
        public IEnumerable<dynamic> ObtenerReporte()
        {
            return _repoMarchamo.ObtenerReporteEstado();
        }
    }
}