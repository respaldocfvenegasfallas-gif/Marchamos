﻿using Marchamo.AccesoDatos;
using Marchamo.Entidades;
using System;
using System.Collections.Generic;

namespace Marchamo.LogicaNegocio
{
    public class PagoLogica
    {
        private readonly PagoRepository _repositorio;

        public PagoLogica()
        {
            _repositorio = new PagoRepository();
        }

        public void RegistrarPago(int idMarchamo, int idMedioPago, decimal monto, string usuario)
        {
            if (monto <= 0)
                throw new ApplicationException("El monto a pagar debe ser mayor a cero.");

            _repositorio.RegistrarPago(idMarchamo, idMedioPago, monto, usuario);
        }

        public IEnumerable<Pago> ListarPagos(int idMarchamo)
        {
            return _repositorio.ListarPorMarchamo(idMarchamo);
        }
    }
}