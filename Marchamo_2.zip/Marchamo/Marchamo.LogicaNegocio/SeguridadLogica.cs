﻿using Marchamo.AccesoDatos;
using Marchamo.Entidades;
using System;
using System.Security.Cryptography;
using System.Text;

namespace Marchamo.LogicaNegocio
{
    public class SeguridadLogica
    {
        private readonly SeguridadRepository _repositorio;

        public SeguridadLogica()
        {
            _repositorio = new SeguridadRepository();
        }

        // =========================================================================
        // 1. MÉTODO PARA LOGIN (Ingreso al sistema)
        // =========================================================================
        public SegUsuario ValidarAcceso(string nombreUsuario, string password, string ip)
        {
            try
            {
                // Buscamos si el usuario existe en BD
                var usuario = _repositorio.ObtenerPorUsuario(nombreUsuario);

                // Si no existe o está inactivo, rechazamos y registramos intento
                if (usuario == null || !usuario.EsActivo)
                {
                    // Usamos ID 0 si no existe el usuario, para no romper la FK de bitácora
                    int idParaBitacora = (usuario != null) ? usuario.IdUsuario : 0;

                    // Registramos el fallo si el usuario existía pero estaba inactivo
                    if (usuario != null)
                        _repositorio.RegistrarBitacora(idParaBitacora, false, ip, "Usuario inactivo o bloqueado");

                    return null;
                }

                // Validamos que la contraseña coincida con el Hash guardado
                if (!VerificarPassword(password, usuario.ClaveHash, usuario.ClaveSalt))
                {
                    _repositorio.RegistrarBitacora(usuario.IdUsuario, false, ip, "Contraseña incorrecta");
                    return null;
                }

                // ¡Login Exitoso!
                _repositorio.RegistrarBitacora(usuario.IdUsuario, true, ip, "Ingreso exitoso al sistema");
                return usuario;
            }
            catch (Exception ex)
            {
                throw new Exception("Error al intentar validar el acceso.", ex);
            }
        }

        // =========================================================================
        // 2. [NUEVO] REGISTRO COMPLETO DE CLIENTE (Propietario + Usuario)
        // =========================================================================
        public int RegistrarClienteCompleto(Propietario propietario, string password)
        {
            // 1. Generamos la seguridad (Hash y Salt) para la contraseña
            CrearHashPassword(password, out byte[] hash, out byte[] salt);

            // 2. Llamamos al método transaccional del repositorio
            // Este método creará al Propietario, al Usuario y le asignará el Rol de Cliente
            return _repositorio.RegistrarClienteCompleto(propietario, hash, salt);
        }

        // =========================================================================
        // 3. REGISTRO SIMPLE (Para uso Administrativo o creación manual)
        // =========================================================================
        public int RegistrarNuevoUsuario(string nombreUsuario, string password, string nombreCompleto, string correo)
        {
            CrearHashPassword(password, out byte[] hashGenerado, out byte[] saltGenerado);

            var nuevoUsuario = new SegUsuario
            {
                NombreUsuario = nombreUsuario,
                ClaveHash = hashGenerado,
                ClaveSalt = saltGenerado,
                NombreCompleto = nombreCompleto,
                Correo = correo,
                EsActivo = true
            };

            return _repositorio.RegistrarUsuario(nuevoUsuario, "WebAdmin");
        }

        // =========================================================================
        // 4. MÉTODOS PRIVADOS DE CRIPTOGRAFÍA (Helpers)
        // =========================================================================

        private bool VerificarPassword(string passwordIngresado, byte[] hashGuardado, byte[] saltGuardado)
        {
            if (string.IsNullOrEmpty(passwordIngresado)) return false;
            if (hashGuardado == null || hashGuardado.Length == 0) return false;
            if (saltGuardado == null || saltGuardado.Length == 0) return false;

            using (var hmac = new HMACSHA512(saltGuardado))
            {
                var hashCalculado = hmac.ComputeHash(Encoding.UTF8.GetBytes(passwordIngresado));
                for (int i = 0; i < hashCalculado.Length; i++)
                {
                    if (hashCalculado[i] != hashGuardado[i]) return false;
                }
            }
            return true;
        }

        private void CrearHashPassword(string password, out byte[] passwordHash, out byte[] passwordSalt)
        {
            using (var hmac = new HMACSHA512())
            {
                passwordSalt = hmac.Key;
                passwordHash = hmac.ComputeHash(Encoding.UTF8.GetBytes(password));
            }
        }
    }
}