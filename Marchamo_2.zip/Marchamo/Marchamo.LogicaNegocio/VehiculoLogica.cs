﻿using Marchamo.AccesoDatos;
using Marchamo.Entidades;
using System;
using System.Collections.Generic;

namespace Marchamo.LogicaNegocio
{
    public class VehiculoLogica
    {
        private readonly VehiculoRepository _repositorio;

        public VehiculoLogica()
        {
            _repositorio = new VehiculoRepository();
        }

        public int Insertar(Vehiculo entidad, string usuario)
        {
            ValidarDatos(entidad);
            return _repositorio.Insertar(entidad, usuario);
        }

        public void Actualizar(Vehiculo entidad, string usuario)
        {
            ValidarDatos(entidad);
            _repositorio.Actualizar(entidad, usuario);
        }

        private void ValidarDatos(Vehiculo entidad)
        {
            if (entidad.Annio < 1900 || entidad.Annio > DateTime.Now.Year + 1)
                throw new ApplicationException("El año del vehículo no es válido.");

            if (entidad.ValorFiscal < 0)
                throw new ApplicationException("El valor fiscal no puede ser negativo.");

            if (entidad.PorcentajeExoneracion < 0 || entidad.PorcentajeExoneracion > 100)
                throw new ApplicationException("El porcentaje de exoneración debe estar entre 0 y 100.");
        }

        public void Eliminar(int idVehiculo, string usuario)
        {
            _repositorio.Eliminar(idVehiculo, usuario);
        }

        public IEnumerable<Vehiculo> Listar(string busqueda = null)
        {
            return _repositorio.Listar(busqueda);
        }

        public Vehiculo ObtenerPorId(int id)
        {
            return _repositorio.ObtenerPorId(id);
        }
    }
}