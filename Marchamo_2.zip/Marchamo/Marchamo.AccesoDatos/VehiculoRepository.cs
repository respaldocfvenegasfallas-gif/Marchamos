﻿using Dapper;
using Marchamo.Entidades;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Marchamo.AccesoDatos
{
    public class VehiculoRepository : BaseRepository
    {
        public int Insertar(Vehiculo entidad, string usuario)
        {
            using (var db = CreateConnection())
            {
                var p = new
                {
                    placa = entidad.Placa,
                    id_propietario = entidad.IdPropietario,
                    id_tipo_vehiculo = entidad.IdTipoVehiculo,
                    marca = entidad.Marca,
                    modelo = entidad.Modelo,
                    annio = entidad.Annio,
                    cilindraje = entidad.Cilindraje,
                    valor_fiscal = entidad.ValorFiscal,
                    porc_exo = entidad.PorcentajeExoneracion,
                    usuario = usuario
                };
                return db.ExecuteScalar<int>("usp_Vehiculo_Insertar", p, commandType: CommandType.StoredProcedure);
            }
        }

        public void Actualizar(Vehiculo entidad, string usuario)
        {
            using (var db = CreateConnection())
            {
                var p = new
                {
                    id_vehiculo = entidad.IdVehiculo,
                    id_propietario = entidad.IdPropietario,
                    id_tipo_vehiculo = entidad.IdTipoVehiculo,
                    marca = entidad.Marca,
                    modelo = entidad.Modelo,
                    annio = entidad.Annio,
                    cilindraje = entidad.Cilindraje,
                    valor_fiscal = entidad.ValorFiscal,
                    porc_exo = entidad.PorcentajeExoneracion,
                    usuario = usuario
                };
                db.Execute("usp_Vehiculo_Actualizar", p, commandType: CommandType.StoredProcedure);
            }
        }

        public void Eliminar(int idVehiculo, string usuario)
        {
            using (var db = CreateConnection())
            {
                var p = new { id_vehiculo = idVehiculo, usuario = usuario };
                db.Execute("usp_Vehiculo_EliminarLogico", p, commandType: CommandType.StoredProcedure);
            }
        }

        public IEnumerable<Vehiculo> Listar(string busqueda = null, int pagina = 1, int pageSize = 10)
        {
            using (var db = CreateConnection())
            {

                var p = new { search = busqueda, page = pagina, pageSize = pageSize };
                return db.Query<Vehiculo>("usp_Vehiculo_Listar", p, commandType: CommandType.StoredProcedure).ToList();
            }
        }

        public Vehiculo ObtenerPorId(int id)
        {
            using (var db = CreateConnection())
            {
                var p = new { id_vehiculo = id };
                return db.QueryFirstOrDefault<Vehiculo>("usp_Vehiculo_ObtenerPorId", p, commandType: CommandType.StoredProcedure);
            }
        }
    }
}