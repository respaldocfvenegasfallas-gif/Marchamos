﻿using Dapper;
using Marchamo.Entidades;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Marchamo.AccesoDatos
{
    public class CatalogosRepository : BaseRepository
    {
        public IEnumerable<TipoVehiculo> ListarTiposVehiculo()
        {
            using (var db = CreateConnection())
            {
                return db.Query<TipoVehiculo>("usp_TipoVehiculo_Listar", commandType: CommandType.StoredProcedure).ToList();
            }
        }

        public IEnumerable<MedioPago> ListarMediosPago()
        {
            using (var db = CreateConnection())
            {
                return db.Query<MedioPago>("usp_MedioPago_Listar", commandType: CommandType.StoredProcedure).ToList();
            }
        }

        public IEnumerable<SeguroAdicional> ListarSegurosAdicionales()
        {
            using (var db = CreateConnection())
            {
                return db.Query<SeguroAdicional>("usp_SeguroAdicional_ListarWeb", commandType: CommandType.StoredProcedure).ToList();
            }
        }
    }
}