﻿using Dapper;
using Marchamo.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Marchamo.AccesoDatos
{
    public class MarchamoRepository : BaseRepository
    {
        // Genera el marchamo
        public Marchamo.Entidades.Marchamo Generar(int idVehiculo, int annio, DateTime fechaVencimiento, string usuario)
        {
            using (var db = CreateConnection())
            {
                var p = new
                {
                    id_vehiculo = idVehiculo,
                    annio = annio,
                    fecha_venc = fechaVencimiento,
                    usuario = usuario
                };
                return db.QueryFirstOrDefault<Marchamo.Entidades.Marchamo>("usp_Marchamo_Generar", p, commandType: CommandType.StoredProcedure);
            }
        }

        // Consulta pública
        public IEnumerable<dynamic> ConsultarPorPlaca(string placa)
        {
            using (var db = CreateConnection())
            {
                var p = new { placa = placa };
                return db.Query<dynamic>("usp_Marchamo_ConsultarPorPlaca", p, commandType: CommandType.StoredProcedure).ToList();
            }
        }

        // Detalle de rubros
        public IEnumerable<dynamic> ObtenerDetalle(int idMarchamo)
        {
            using (var db = CreateConnection())
            {
                var p = new { id_marchamo = idMarchamo };
                return db.Query<dynamic>("usp_Marchamo_ListarDetalle", p, commandType: CommandType.StoredProcedure).ToList();
            }
        }

        // Agregar seguro
        public void AgregarSeguroAdicional(int idMarchamo, int idSeguroAdicional, string usuario)
        {
            using (var db = CreateConnection())
            {
                var p = new
                {
                    id_marchamo = idMarchamo,
                    id_seguro_adicional = idSeguroAdicional,
                    usuario = usuario
                };
                db.Execute("usp_Marchamo_AgregarSeguroAdicional", p, commandType: CommandType.StoredProcedure);
            }
        }

        // [NUEVO] REPORTE DE ESTADO (Para Dashboard Admin)
        public IEnumerable<dynamic> ObtenerReporteEstado()
        {
            using (var db = CreateConnection())
            {
                return db.Query<dynamic>("usp_Reporte_EstadoMarchamos", commandType: CommandType.StoredProcedure).ToList();
            }
        }
    }
}