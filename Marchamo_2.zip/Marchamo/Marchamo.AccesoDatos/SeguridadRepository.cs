﻿using Dapper;
using Marchamo.Entidades;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Marchamo.AccesoDatos
{
    public class SeguridadRepository : BaseRepository
    {
        // 1. LOGIN: Obtener usuario por nombre (Cédula o Admin)
        public SegUsuario ObtenerPorUsuario(string nombreUsuario)
        {
            using (var db = CreateConnection())
            {
                var p = new { nombre_usuario = nombreUsuario };
                return db.QueryFirstOrDefault<SegUsuario>("usp_SegUsuario_ObtenerPorNombre", p, commandType: CommandType.StoredProcedure);
            }
        }

        // 2. BITÁCORA: Registrar accesos
        public void RegistrarBitacora(int idUsuario, bool exitoso, string ip, string detalle)
        {
            using (var db = CreateConnection())
            {
                var p = new
                {
                    id_usuario = idUsuario,
                    exitoso = exitoso,
                    direccion_IP = ip,
                    detalle = detalle
                };
                db.Execute("usp_SegBitacora_Insertar", p, commandType: CommandType.StoredProcedure);
            }
        }

        // 3. REGISTRO SIMPLE (Para crear Funcionarios desde Admin)
        public int RegistrarUsuario(SegUsuario usuario, string creador)
        {
            using (var db = CreateConnection())
            {
                var p = new
                {
                    nombre_usuario = usuario.NombreUsuario,
                    clave_hash = usuario.ClaveHash,
                    clave_salt = usuario.ClaveSalt,
                    nombre_completo = usuario.NombreCompleto,
                    correo = usuario.Correo,
                    usuario_crea = creador
                };
                return db.ExecuteScalar<int>("usp_SegUsuario_Registrar", p, commandType: CommandType.StoredProcedure);
            }
        }

        // 4. REGISTRO INTEGRAL DE CLIENTE (Propietario + Usuario)
        public int RegistrarClienteCompleto(Propietario prop, byte[] hash, byte[] salt)
        {
            using (var db = CreateConnection())
            {
                var p = new
                {
                    cedula = prop.Cedula,
                    nombre = prop.Nombre,
                    apellido1 = prop.Apellido1,
                    apellido2 = prop.Apellido2,
                    telefono = prop.Telefono,
                    correo = prop.Correo,
                    direccion = prop.Direccion,
                    clave_hash = hash,
                    clave_salt = salt
                };
                return db.ExecuteScalar<int>("usp_Cliente_RegistrarCompleto", p, commandType: CommandType.StoredProcedure);
            }
        }

        // 5. [NUEVO] LISTAR USUARIOS (Para el Dashboard Admin)
        public IEnumerable<dynamic> ListarUsuariosAdmin()
        {
            using (var db = CreateConnection())
            {
                return db.Query<dynamic>("usp_Admin_ListarUsuarios", commandType: CommandType.StoredProcedure).ToList();
            }
        }

        // 6. [NUEVO] CAMBIAR ESTADO USUARIO (Activar/Desactivar)
        public void CambiarEstadoUsuario(int idUsuario, bool activo)
        {
            using (var db = CreateConnection())
            {
                var p = new { id_usuario = idUsuario, activo = activo };
                db.Execute("usp_Admin_CambiarEstadoUsuario", p, commandType: CommandType.StoredProcedure);
            }
        }
    }
}