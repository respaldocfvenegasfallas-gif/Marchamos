﻿using Dapper;
using Marchamo.Entidades;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Marchamo.AccesoDatos
{
    public class PagoRepository : BaseRepository
    {
        public void RegistrarPago(int idMarchamo, int idMedioPago, decimal monto, string usuario)
        {
            using (var db = CreateConnection())
            {
                var p = new
                {
                    id_marchamo = idMarchamo,
                    id_medio_pago = idMedioPago,
                    monto = monto,
                    usuario = usuario
                };
                db.Execute("usp_Pago_Registrar", p, commandType: CommandType.StoredProcedure);
            }
        }

        public IEnumerable<Pago> ListarPorMarchamo(int idMarchamo)
        {
            using (var db = CreateConnection())
            {
                var p = new { id_marchamo = idMarchamo };
                return db.Query<Pago>("usp_Pago_ListarPorMarchamo", p, commandType: CommandType.StoredProcedure).ToList();
            }
        }
    }
}