﻿using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace Marchamo.AccesoDatos
{
    public abstract class BaseRepository
    {
        private readonly string _connectionString;

        protected BaseRepository()
        {
            _connectionString = ConfigurationManager.ConnectionStrings["CN_Marchamo"].ConnectionString;
        }

        // Crea la conexión (Dapper la abrirá y cerrará automáticamente si se usa correctamente,
        // pero el 'using' en los métodos es la mejor práctica).
        protected IDbConnection CreateConnection()
        {
            return new SqlConnection(_connectionString);
        }
    }
}