﻿using Dapper;
using Marchamo.Entidades;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Marchamo.AccesoDatos
{
    public class PropietarioRepository : BaseRepository
    {
        public int Insertar(Propietario entidad, string usuario)
        {
            using (var db = CreateConnection())
            {
                var p = new
                {
                    cedula = entidad.Cedula,
                    nombre = entidad.Nombre,
                    apellido1 = entidad.Apellido1,
                    apellido2 = entidad.Apellido2,
                    telefono = entidad.Telefono,
                    correo = entidad.Correo,
                    direccion = entidad.Direccion,
                    usuario = usuario
                };
                return db.ExecuteScalar<int>("usp_Propietario_Insertar", p, commandType: CommandType.StoredProcedure);
            }
        }

        public void Actualizar(Propietario entidad, string usuario)
        {
            using (var db = CreateConnection())
            {
                var p = new
                {
                    id_propietario = entidad.IdPropietario,
                    nombre = entidad.Nombre,
                    apellido1 = entidad.Apellido1,
                    apellido2 = entidad.Apellido2,
                    telefono = entidad.Telefono,
                    correo = entidad.Correo,
                    direccion = entidad.Direccion,
                    usuario = usuario
                };
                db.Execute("usp_Propietario_Actualizar", p, commandType: CommandType.StoredProcedure);
            }
        }

        public void Eliminar(int idPropietario, string usuario)
        {
            using (var db = CreateConnection())
            {
                var p = new { id_propietario = idPropietario, usuario = usuario };
                db.Execute("usp_Propietario_EliminarLogico", p, commandType: CommandType.StoredProcedure);
            }
        }

        public IEnumerable<Propietario> Listar(string busqueda = null, int pagina = 1, int pageSize = 10)
        {
            using (var db = CreateConnection())
            {
                var p = new { search = busqueda, page = pagina, pageSize = pageSize };
                return db.Query<Propietario>("usp_Propietario_Listar", p, commandType: CommandType.StoredProcedure).ToList();
            }
        }

        public Propietario ObtenerPorId(int id)
        {
            using (var db = CreateConnection())
            {
                var p = new { id_propietario = id };
                return db.QueryFirstOrDefault<Propietario>("usp_Propietario_ObtenerPorId", p, commandType: CommandType.StoredProcedure);
            }
        }
    }
}