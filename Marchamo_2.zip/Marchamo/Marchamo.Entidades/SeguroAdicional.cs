﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Marchamo.Entidades
{
    public class SeguroAdicional
    {
        public int IdSeguroAdicional { get; set; }

        [Required]
        [StringLength(80)]
        [Display(Name = "Nombre del Seguro")]
        public string Nombre { get; set; }

        [StringLength(200)]
        public string Descripcion { get; set; }

        public int? IdTipoVehiculo { get; set; }

        [Required]
        [DataType(DataType.Currency)]
        [Display(Name = "Prima Base")]
        public decimal PrimaBase { get; set; }

        public bool EsVisibleWeb { get; set; }
        public bool EsActivo { get; set; }
        public string UsuarioCrea { get; set; }
        public DateTime FechaCrea { get; set; }
        public string UsuarioModifica { get; set; }
        public DateTime? FechaModifica { get; set; }
    }
}