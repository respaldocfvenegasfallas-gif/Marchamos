﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Marchamo.Entidades
{
    public class SegUsuario
    {
        public int IdUsuario { get; set; }

        [Required(ErrorMessage = "El nombre de usuario es obligatorio.")]
        [StringLength(50)]
        [Display(Name = "Usuario")]
        public string NombreUsuario { get; set; }

        // Nota: ClaveHash y ClaveSalt no suelen llevar validaciones de UI porque no se editan en texto plano
        public byte[] ClaveHash { get; set; }
        public byte[] ClaveSalt { get; set; }

        [Required(ErrorMessage = "El nombre completo es obligatorio.")]
        [StringLength(120)]
        [Display(Name = "Nombre Completo")]
        public string NombreCompleto { get; set; }

        [StringLength(100)]
        [EmailAddress]
        public string Correo { get; set; }

        public int IntentosFallidos { get; set; }

        [Display(Name = "Último Inicio de Sesión")]
        public DateTime? UltimoLogin { get; set; }

        public bool EsActivo { get; set; }
        public string UsuarioCrea { get; set; }
        public DateTime FechaCrea { get; set; }
        public string UsuarioModifica { get; set; }
        public DateTime? FechaModifica { get; set; }
    }
}