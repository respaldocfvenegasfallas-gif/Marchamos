﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Marchamo.Entidades
{
    public class EstadoMarchamo
    {
        public int IdEstadoMarchamo { get; set; }

        [Required]
        [StringLength(30)]
        public string Nombre { get; set; }
    }
}