﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Marchamo.Entidades
{
    public class SegUsuarioRol
    {
        public int IdUsuario { get; set; }               // id_usuario (PK compuesta)
        public int IdRol { get; set; }                   // id_rol (PK compuesta)
        public System.DateTime FechaAsignacion { get; set; } // fecha_asignacion

    }
}
