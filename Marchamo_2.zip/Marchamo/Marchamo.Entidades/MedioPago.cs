﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Marchamo.Entidades
{
    public class MedioPago
    {
        public int IdMedioPago { get; set; }

        [Required]
        [StringLength(40)]
        [Display(Name = "Medio de Pago")]
        public string Nombre { get; set; }

        public bool EsActivo { get; set; }
        public string UsuarioCrea { get; set; }
        public DateTime FechaCrea { get; set; }
        public string UsuarioModifica { get; set; }
        public DateTime? FechaModifica { get; set; }
    }
}