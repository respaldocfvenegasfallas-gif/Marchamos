﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Marchamo.Entidades
{
    public class Auditoria
    {
        public int IdAuditoria { get; set; }             // id_auditoria
        public string NombreTabla { get; set; }          // nombre_tabla
        public string ClaveRegistro { get; set; }        // clave_registro
        public string TipoOperacion { get; set; }        // tipo_operacion
        public string ValoresAnteriores { get; set; }    // valores_anteriores
        public string ValoresNuevos { get; set; }        // valores_nuevos
        public string UsuarioAccion { get; set; }        // usuario_accion
        public System.DateTime FechaAccion { get; set; } // fecha_accion

    }
}
