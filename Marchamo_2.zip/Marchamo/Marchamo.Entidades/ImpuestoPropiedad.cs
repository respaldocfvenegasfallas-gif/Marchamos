﻿using System;

namespace Marchamo.Entidades
{
    public class ImpuestoPropiedad
    {
        public int IdTramo { get; set; }
        public int Periodo { get; set; }
        public decimal MontoDesde { get; set; }
        public decimal MontoHasta { get; set; }
        public decimal Porcentaje { get; set; }
        public decimal MontoBase { get; set; }
    }
}