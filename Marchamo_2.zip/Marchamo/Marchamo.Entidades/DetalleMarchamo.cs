﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Marchamo.Entidades
{
    public class DetalleMarchamo
    {
        public int IdDetalle { get; set; }               // id_detalle
        public int IdMarchamo { get; set; }              // id_marchamo
        public int IdTipoConcepto { get; set; }          // id_tipo_concepto
        public decimal MontoCalculado { get; set; }      // monto_calculado
        public decimal? MontoAjustado { get; set; }      // monto_ajustado
        public string Observaciones { get; set; }        // observaciones

    }
}
