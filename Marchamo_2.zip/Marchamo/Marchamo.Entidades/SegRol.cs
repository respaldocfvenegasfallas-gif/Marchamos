﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Marchamo.Entidades
{
    public class SegRol
    {
        public int IdRol { get; set; }

        [Required(ErrorMessage = "El nombre del rol es obligatorio.")]
        [StringLength(50)]
        [Display(Name = "Rol")]
        public string Nombre { get; set; }

        [StringLength(200)]
        [DataType(DataType.MultilineText)]
        [Display(Name = "Descripción")]
        public string Descripcion { get; set; }

        [Display(Name = "¿Es Administrador?")]
        public bool EsAdministrador { get; set; }

        public bool EsActivo { get; set; }
        public string UsuarioCrea { get; set; }
        public DateTime FechaCrea { get; set; }
        public string UsuarioModifica { get; set; }
        public DateTime? FechaModifica { get; set; }
    }
}