﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Marchamo.Entidades
{
    public class TipoConceptoMarchamo
    {
        public int IdTipoConcepto { get; set; }          // id_tipo_concepto
        public string Codigo { get; set; }               // codigo
        public string Nombre { get; set; }               // nombre
        public bool EsObligatorio { get; set; }          // es_Obligatorio
        public int OrdenPresentacion { get; set; }       // orden_presentacion
        public bool EsActivo { get; set; }               // es_activo
        public string UsuarioCrea { get; set; }          // usuario_crea
        public System.DateTime FechaCrea { get; set; }   // fecha_crea
        public string UsuarioModifica { get; set; }      // usuario_modifica
        public System.DateTime? FechaModifica { get; set; } // fecha_modifica

    }
}
