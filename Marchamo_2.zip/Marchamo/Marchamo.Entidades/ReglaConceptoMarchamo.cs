﻿using System;

namespace Marchamo.Entidades
{
    public class ReglaConceptoMarchamo
    {
        public int IdRegla { get; set; }
        public int IdTipoConcepto { get; set; }
        public int? IdTipoVehiculo { get; set; }
        public int AnnioDesde { get; set; }
        public int AnnioHasta { get; set; }
        public string TipoCalculo { get; set; }
        public decimal? Porcentaje { get; set; }
        public decimal? MontoFijo { get; set; }
        public bool EsActivo { get; set; }
        public string UsuarioCrea { get; set; }
        public DateTime FechaCrea { get; set; }
        public string UsuarioModifica { get; set; }
        public DateTime? FechaModifica { get; set; }
    }
}