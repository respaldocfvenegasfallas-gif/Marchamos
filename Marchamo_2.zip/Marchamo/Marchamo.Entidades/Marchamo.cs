﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Marchamo.Entidades
{
    public class Marchamo
    {
        public int IdMarchamo { get; set; }
        public int IdVehiculo { get; set; }
        public int Annio { get; set; }
        public DateTime FechaEmision { get; set; }
        public DateTime FechaVencimiento { get; set; }
        public int IdEstadoMarchamo { get; set; }

        [DataType(DataType.Currency)]
        public decimal TotalPagar { get; set; }

        public string CodigoMarchamo { get; set; }
        public bool EsActivo { get; set; }
        public string UsuarioCrea { get; set; }
        public DateTime FechaCrea { get; set; }
        public string UsuarioModifica { get; set; }
        public DateTime? FechaModifica { get; set; }
    }
}