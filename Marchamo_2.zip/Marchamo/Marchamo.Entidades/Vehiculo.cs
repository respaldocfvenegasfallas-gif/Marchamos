﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Marchamo.Entidades
{
    public class Vehiculo
    {
        public int IdVehiculo { get; set; }

        [Required(ErrorMessage = "La placa es obligatoria.")]
        [StringLength(10, ErrorMessage = "La placa no puede exceder 10 caracteres.")]
        public string Placa { get; set; }

        [Required(ErrorMessage = "Debe seleccionar un propietario.")]
        public int IdPropietario { get; set; }

        // Propiedad de lectura (No se guarda en BD, se llena en consultas)
        public string PropietarioNombre { get; set; }

        [Required(ErrorMessage = "Debe seleccionar un tipo de vehículo.")]
        public int IdTipoVehiculo { get; set; }

        // Propiedad de lectura
        public string TipoNombre { get; set; }

        [Required(ErrorMessage = "La marca es obligatoria.")]
        [StringLength(50)]
        public string Marca { get; set; }

        [Required(ErrorMessage = "El modelo es obligatorio.")]
        [StringLength(50)]
        public string Modelo { get; set; }

        [Required]
        [Range(1900, 2100, ErrorMessage = "Año inválido.")]
        public int Annio { get; set; }

        public int? Cilindraje { get; set; }

        [Required]
        [DataType(DataType.Currency)]
        public decimal ValorFiscal { get; set; }

        [Range(0, 100, ErrorMessage = "La exoneración debe estar entre 0 y 100.")]
        [Display(Name = "% Exoneración")]
        public decimal PorcentajeExoneracion { get; set; }

        public DateTime FechaRegistro { get; set; }
        public bool EsActivo { get; set; }
        public string UsuarioCrea { get; set; }
        public DateTime FechaCrea { get; set; }
        public string UsuarioModifica { get; set; }
        public DateTime? FechaModifica { get; set; }
    }
}