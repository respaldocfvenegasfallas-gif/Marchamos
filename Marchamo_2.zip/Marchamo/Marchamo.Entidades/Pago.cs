﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Marchamo.Entidades
{
    public class Pago
    {
        public int IdPago { get; set; }
        public int IdMarchamo { get; set; }

        [Display(Name = "Fecha de Pago")]
        public DateTime FechaPago { get; set; }

        [Required]
        [Display(Name = "Medio de Pago")]
        public int IdMedioPago { get; set; }

        [Required]
        [DataType(DataType.Currency)]
        public decimal Monto { get; set; }

        [StringLength(50)]
        [Display(Name = "Número de Autorización")]
        public string Autorizacion { get; set; }

        [StringLength(100)]
        [Display(Name = "Referencia / Comprobante")]
        public string Referencia { get; set; }

        public bool EsActivo { get; set; }
        public string UsuarioCrea { get; set; }
        public DateTime FechaCrea { get; set; }
        public string UsuarioModifica { get; set; }
        public DateTime? FechaModifica { get; set; }
    }
}