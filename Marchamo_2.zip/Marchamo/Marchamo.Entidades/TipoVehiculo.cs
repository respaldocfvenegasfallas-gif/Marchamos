﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Marchamo.Entidades
{
    public class TipoVehiculo
    {
        public int IdTipoVehiculo { get; set; }

        [Required]
        [StringLength(40)]
        public string Nombre { get; set; }

        [StringLength(5)]
        public string CodigoHacienda { get; set; }

        public bool UsaSOAEspecial { get; set; }
        public bool EsActivo { get; set; }
        public string UsuarioCrea { get; set; }
        public DateTime FechaCrea { get; set; }
        public string UsuarioModifica { get; set; }
        public DateTime? FechaModifica { get; set; }
    }
}