﻿using System.Web.Http;

namespace Marchamo.Web
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Habilitar rutas por atributos (Ej: [Route("api/marchamo/consultar")])
            config.MapHttpAttributeRoutes();

            // Ruta por defecto de la API
            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            // Forzar respuesta en JSON (eliminar XML para evitar problemas con navegadores)
            config.Formatters.Remove(config.Formatters.XmlFormatter);
            config.Formatters.JsonFormatter.SerializerSettings.Formatting = Newtonsoft.Json.Formatting.Indented;
        }
    }
}