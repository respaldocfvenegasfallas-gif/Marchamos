﻿using Marchamo.LogicaNegocio;
using System;
using System.Web.Http;

namespace Marchamo.Web.ControllersApi
{
    [RoutePrefix("api/pago")]
    public class PagoController : ApiController
    {
        private readonly PagoLogica _logica = new PagoLogica();

        [HttpPost]
        [Route("procesar")]
        public IHttpActionResult ProcesarPago(PagoRequest req)
        {
            try
            {
                // OJO: Aquí no guardamos la tarjeta, solo el monto y la referencia
                // El frontend ya debió haber creado el usuario con SeguridadController antes de llamar aquí.

                // Simulación de validación de tarjeta...
                if (string.IsNullOrEmpty(req.NumeroTarjeta) || req.NumeroTarjeta.Length < 16)
                    return BadRequest("Tarjeta inválida");

                _logica.RegistrarPago(req.IdMarchamo, 1, req.Monto, req.NombreUsuario); // 1 = Tarjeta (ID fijo por ahora)

                return Ok("Pago exitoso");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        public class PagoRequest
        {
            public int IdMarchamo { get; set; }
            public decimal Monto { get; set; }
            public string NombreUsuario { get; set; }
            public string NumeroTarjeta { get; set; }
            public string CVV { get; set; }
        }
    }
}