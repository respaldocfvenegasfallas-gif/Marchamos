﻿using Marchamo.LogicaNegocio;
using System.Web.Http;

namespace Marchamo.Web.ControllersApi
{
    [RoutePrefix("api/catalogos")]
    public class CatalogosController : ApiController
    {
        private readonly CatalogosLogica _logica = new CatalogosLogica();

        [HttpGet]
        [Route("vehiculos")]
        public IHttpActionResult GetTiposVehiculo()
        {
            return Ok(_logica.ListarTiposVehiculo());
        }

        [HttpGet]
        [Route("mediospago")]
        public IHttpActionResult GetMediosPago()
        {
            return Ok(_logica.ListarMediosPago());
        }

        [HttpGet]
        [Route("seguros")]
        public IHttpActionResult GetSeguros()
        {
            return Ok(_logica.ListarSegurosAdicionales());
        }
    }
}