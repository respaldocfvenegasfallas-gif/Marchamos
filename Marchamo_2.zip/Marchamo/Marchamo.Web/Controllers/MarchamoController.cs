﻿using Marchamo.LogicaNegocio;
using System;
using System.Web.Http;

namespace Marchamo.Web.ControllersApi
{
    [RoutePrefix("api/marchamo")]
    public class MarchamoController : ApiController
    {
        private readonly MarchamoLogica _logica = new MarchamoLogica();

        [HttpGet]
        [Route("consultar/{placa}")]
        public IHttpActionResult Consultar(string placa)
        {
            try
            {
                var resultado = _logica.ConsultarPorPlaca(placa);

                // Si está vacío, devolvemos un 404 lógico o un objeto vacío, según prefieras
                // Aquí devolvemos OK con lista vacía para que JS decida qué mostrar
                return Ok(resultado);
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        [HttpGet]
        [Route("detalle/{idMarchamo}")]
        public IHttpActionResult ObtenerDetalle(int idMarchamo)
        {
            try
            {
                return Ok(_logica.ObtenerDetalle(idMarchamo));
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        // Endpoint administrativo (Opcional, para que puedas crear marchamos y probar)
        [HttpPost]
        [Route("generar")]
        public IHttpActionResult Generar([FromBody] int idVehiculo)
        {
            try
            {
                // Usuario quemado 'Admin' porque es una prueba interna
                var marchamo = _logica.GenerarMarchamo(idVehiculo, "Admin");
                return Ok(marchamo);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [Route("agregar-seguro")]
        public IHttpActionResult AgregarSeguro(SeguroRequest req)
        {
            try
            {
                _logica.AgregarSeguroAdicional(req.IdMarchamo, req.IdSeguro, "WebUser");
                return Ok("Seguro agregado");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        public class SeguroRequest { public int IdMarchamo { get; set; } public int IdSeguro { get; set; } }
    }
}