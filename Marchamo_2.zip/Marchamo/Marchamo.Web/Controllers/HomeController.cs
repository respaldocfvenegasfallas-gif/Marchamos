﻿using System.Web.Mvc;

namespace Marchamo.Web.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Title = "Consulta de Marchamo";
            return View();
        }

        // Página de confirmación después de pagar
        public ActionResult Confirmacion()
        {
            return View();
        }
    }
}