﻿using Marchamo.Entidades;
using Marchamo.LogicaNegocio;
using System;
using System.Web;
using System.Web.Http;

namespace Marchamo.Web.ControllersApi
{
    [RoutePrefix("api/seguridad")]
    public class SeguridadController : ApiController
    {
        private readonly SeguridadLogica _logica = new SeguridadLogica();

        // 1. LOGIN (API para Apps móviles o AJAX si se requiere)
        [HttpPost]
        [Route("login")]
        public IHttpActionResult Login(LoginViewModel modelo)
        {
            try
            {
                if (modelo == null) return BadRequest("Datos inválidos.");

                string ip = HttpContext.Current != null ? HttpContext.Current.Request.UserHostAddress : "0.0.0.0";

                var usuario = _logica.ValidarAcceso(modelo.Usuario, modelo.Password, ip);

                if (usuario == null)
                    return BadRequest("Usuario o contraseña incorrectos.");

                return Ok(new
                {
                    IdUsuario = usuario.IdUsuario,
                    Nombre = usuario.NombreCompleto,
                    Rol = "Cliente" // En un futuro podrías leer el rol real de la BD
                });
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        // 2. REGISTRO COMPLETO (Propietario + Usuario)
        // Este endpoint recibe todos los datos del formulario de pago para crear el perfil completo
        [HttpPost]
        [Route("registro")]
        public IHttpActionResult Registro(RegistroCompletoViewModel modelo)
        {
            try
            {
                if (modelo == null) return BadRequest("Datos incompletos.");

                // Mapeamos el ViewModel a la Entidad Propietario
                var nuevoPropietario = new Propietario
                {
                    Cedula = modelo.Cedula,
                    Nombre = modelo.Nombre,
                    Apellido1 = modelo.Apellido1,
                    Apellido2 = modelo.Apellido2,
                    Correo = modelo.Correo,
                    Telefono = modelo.Telefono,
                    Direccion = modelo.Direccion
                };

                // Llamamos a la lógica que crea Propietario + Usuario (Hash) en una transacción
                int idUsuario = _logica.RegistrarClienteCompleto(nuevoPropietario, modelo.Password);

                return Ok(new
                {
                    Mensaje = "Cliente registrado con éxito",
                    IdUsuario = idUsuario
                });
            }
            catch (Exception ex)
            {
                // Devolvemos el error (ej: "Ya existe un usuario con esa cédula")
                return BadRequest(ex.Message);
            }
        }

        // --- VIEW MODELS (Contratos de datos para la API) ---

        public class LoginViewModel
        {
            public string Usuario { get; set; }
            public string Password { get; set; }
        }

        // ViewModel ampliado para recibir todos los datos del formulario web
        public class RegistroCompletoViewModel
        {
            public string Cedula { get; set; }      // Será el NombreUsuario
            public string Password { get; set; }
            public string Nombre { get; set; }
            public string Apellido1 { get; set; }
            public string Apellido2 { get; set; }
            public string Correo { get; set; }
            public string Telefono { get; set; }
            public string Direccion { get; set; }
        }
    }
}