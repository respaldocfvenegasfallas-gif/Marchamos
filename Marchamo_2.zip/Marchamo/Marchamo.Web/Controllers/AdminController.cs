﻿using Marchamo.LogicaNegocio;
using Marchamo.Entidades;
using System.Collections.Generic;
using System.Web;
using System.Web.Mvc;
using System.Linq;

namespace Marchamo.Web.Controllers
{
    public class AdminController : Controller
    {
        private readonly AdminLogica _logicaAdmin = new AdminLogica();
        private readonly SeguridadLogica _logicaSeguridad = new SeguridadLogica();

        // ---------------------------------------------------------
        // 1. LOGIN DE FUNCIONARIO
        // ---------------------------------------------------------
        [HttpPost]
        public ActionResult LoginAdmin(string usuario, string password)
        {
            var user = _logicaSeguridad.ValidarAcceso(usuario, password, "WebAdmin");
            bool esAdminFijo = (usuario == "admin" && password == "123");

            if (user != null || esAdminFijo)
            {
                Session["UsuarioAdmin"] = user != null ? user.NombreCompleto : "Administrador";
                Session["EsAdmin"] = true;
                return RedirectToAction("Dashboard");
            }
            else
            {
                TempData["ErrorLogin"] = "Acceso denegado. Credenciales de funcionario inválidas.";
                return RedirectToAction("Index", "Home");
            }
        }

        public ActionResult Logout()
        {
            Session.Clear();
            return RedirectToAction("Index", "Home");
        }

        // ---------------------------------------------------------
        // 2. DASHBOARD PRINCIPAL (Contenedor de Módulos)
        // ---------------------------------------------------------
        public ActionResult Dashboard()
        {
            if (Session["EsAdmin"] == null) return RedirectToAction("Index", "Home");

            // Creamos un modelo compuesto para pasar todos los datos a la vista única
            var modelo = new AdminDashboardViewModel();

            // Cargar listas
            modelo.ListaUsuarios = _logicaAdmin.ListarUsuarios().ToList();
            modelo.ReporteEstado = _logicaAdmin.ObtenerReporte().ToList();

            return View(modelo);
        }

        // ---------------------------------------------------------
        // 3. ACCIONES DEL DASHBOARD
        // ---------------------------------------------------------

        [HttpPost]
        public ActionResult CargaMasiva(HttpPostedFileBase archivo)
        {
            if (Session["EsAdmin"] == null) return RedirectToAction("Index", "Home");

            if (archivo != null && archivo.ContentLength > 0)
            {
                string usuarioAdmin = Session["UsuarioAdmin"].ToString();
                List<string> errores = _logicaAdmin.ProcesarCargaMasiva(archivo.InputStream, usuarioAdmin);

                if (errores.Count == 0)
                {
                    TempData["Mensaje"] = "Base de datos actualizada correctamente.";
                    TempData["Tipo"] = "success";
                }
                else
                {
                    TempData["Mensaje"] = $"Proceso con {errores.Count} advertencias.";
                    TempData["Errores"] = errores;
                    TempData["Tipo"] = "warning";
                }
            }
            else
            {
                TempData["Mensaje"] = "Archivo inválido.";
                TempData["Tipo"] = "danger";
            }

            return RedirectToAction("Dashboard");
        }

        [HttpPost]
        public ActionResult CambiarEstadoUsuario(int id, bool estado)
        {
            if (Session["EsAdmin"] == null) return new HttpStatusCodeResult(403);

            _logicaAdmin.CambiarEstadoUsuario(id, estado);
            return Json(new { success = true });
        }
    }

    // Clase auxiliar para pasar datos a la vista (ViewModel)
    public class AdminDashboardViewModel
    {
        public List<dynamic> ListaUsuarios { get; set; }
        public List<dynamic> ReporteEstado { get; set; }
    }
}